export const headerRoutes = [
    '/'
]