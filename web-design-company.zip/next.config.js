module.exports = {
    reactStrictMode: true,
  }  